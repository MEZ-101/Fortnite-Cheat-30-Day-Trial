﻿using System;

// Token: 0x0200001B RID: 27
internal class ProcessedByFody
{
	// Token: 0x0400010E RID: 270
	internal const string FodyVersion = "6.0.0.0";

	// Token: 0x0400010F RID: 271
	internal const string Costura = "4.1.0.0";
}s
